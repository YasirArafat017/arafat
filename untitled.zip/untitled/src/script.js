let currentUserRole = "user";
let lastPrice = 0;
let otpAttempts = 0;
const MAX_OTP_ATTEMPTS = 3;

function navigate(id) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  if (id === 'driver') updateDriverPanel();
  if (id === 'tracking') generateTrackingNumber();
}

function showLoginForm() {
  const role = document.getElementById("userRole").value;
  currentUserRole = role;
  document.getElementById("loginForm").style.display = "block";
  document.getElementById("dlField").style.display = (role === "driver") ? "block" : "none";
}

function handleLogin() {
  const role = document.getElementById("userRole").value;
  const phone = document.getElementById("phone").value;
  
  if (!role) return alert("⚠️ অনুগ্রহ করে ভূমিকা নির্বাচন করুন");
  if (!phone || phone.length !== 11) return alert("⚠️ সঠিক মোবাইল নম্বর দিন (11 ডিজিট)");
  
  // Generate and send OTP (simulated)
  const otp = Math.floor(1000 + Math.random() * 9000);
  alert(`OTP পাঠানো হয়েছে ${phone} নম্বরে। টেস্ট OTP: ${otp}`);
  
  document.getElementById("loginForm").style.display = "none";
  document.getElementById("otpVerification").style.display = "block";
}

function verifyOTP() {
  const otpInput = document.getElementById('otp').value;
  otpAttempts++;
  
  if (otpInput === "1234") { // Test OTP
    alert("✅ OTP যাচাই সফল!");
    document.getElementById("otpVerification").style.display = "none";
    navigate(currentUserRole === "driver" ? "driver" : "booking");
  } else {
    if (otpAttempts >= MAX_OTP_ATTEMPTS) {
      alert("❌ OTP যাচাই ব্যর্থ! আপনার অ্যাকাউন্ট সাময়িকভাবে লক করা হয়েছে।");
      document.getElementById("otpVerification").style.display = "none";
      document.getElementById("loginForm").style.display = "block";
      otpAttempts = 0;
    } else {
      alert(`❌ ভুল OTP! আপনি আর ${MAX_OTP_ATTEMPTS - otpAttempts} বার চেষ্টা করতে পারবেন`);
    }
  }
}

function calculatePrice() {
  const weight = document.getElementById("weight").value;
  const destination = document.getElementById("destination").value;
  let price = 0;
  
  if (!weight || weight <= 0) return alert("⚠️ সঠিক ওজন দিন");
  if (!destination) return alert("⚠️ গন্তব্য নির্বাচন করুন");
  
  // Dynamic pricing based on destination
  let baseRate = 20;
  if (destination === "chittagong") baseRate = 25;
  if (destination === "sylhet") baseRate = 30;
  
  price = parseFloat(weight) * baseRate;
  lastPrice = price;
  
  document.getElementById("price").innerText = "মোট দাম: ৳ " + price;
  localStorage.setItem("lastBookingPrice", price);
}

function confirmBooking() {
  if (lastPrice <= 0) return alert("⚠️ প্রথমে দাম ক্যালকুলেট করুন");
  
  const trackingNumber = generateTrackingNumber();
  alert(`✅ বুকিং কনফার্ম হয়েছে!\nট্র্যাকিং নম্বর: ${trackingNumber}`);
  
  document.getElementById("busInfo").style.display = "block";
  document.getElementById("trackingNumber").innerText = trackingNumber;
  updateBookingHistory(trackingNumber);
}

function generateTrackingNumber() {
  const prefix = "BDX";
  const randomNum = Math.floor(100000 + Math.random() * 900000);
  return `${prefix}${randomNum}`;
}

function updateDriverPanel() {
  const driverPriceText = document.getElementById("driverPriceInfo");
  const storedPrice = localStorage.getItem("lastBookingPrice");
  
  if (storedPrice && storedPrice > 0) {
    const fullPrice = parseFloat(storedPrice);
    const commission = fullPrice * 0.29;
    const driverGets = fullPrice - commission;
    
    driverPriceText.innerHTML = `
      <p>💰 এই পার্সেল ডেলিভারির জন্য আপনি পাবেন: ৳ ${driverGets.toFixed(2)}</p>
      <p>📦 পার্সেল সংখ্যা: 1</p>
      <p>📍 গন্তব্য: ${document.getElementById("destination")?.value || "ঢাকা"}</p>
    `;
  } else {
    driverPriceText.innerText = "⚠️ কোনো বুকিং পাওয়া যায়নি।";
  }
}

function markReceived() {
  if (confirm("আপনি কি নিশ্চিত যে আপনি পার্সেলটি পেয়েছেন?")) {
    alert("✅ আপনি পার্সেলটি পেয়ে গেছেন!");
    document.getElementById("receiveStatus").innerText = "স্ট্যাটাস: ডেলিভার্ড";
    document.getElementById("receiveBtn").style.display = "none";
    
    // Show rating section
    document.getElementById("ratingSection").style.display = "block";
  }
}

function generateReceiveDate() {
  const date = new Date();
  const formattedDate = date.toLocaleDateString('bn-BD', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
  document.getElementById('receiveDate').innerText = formattedDate;
}

function submitRating() {
  const rating = document.getElementById("rating").value;
  const feedback = document.getElementById("feedback").value;
  
  if (!rating) return alert("⭐ রেটিং দিন");
  
  alert(`ধন্যবাদ! আপনি ${rating} স্টার রেটিং দিয়েছেন।\nমন্তব্য: ${feedback || "N/A"}`);
  document.getElementById("ratingSection").style.display = "none";
}

function searchParcelById() {
  const parcelId = prompt("পার্সেল আইডি/ট্র্যাকিং নম্বর দিন:");
  
  if (parcelId) {
    // Simulate API call
    setTimeout(() => {
      const statuses = ["অর্ডার প্রসেসিং", "পিকআপ সম্পন্ন", "ট্রানজিটে", "ডেলিভারি প্রসেসিং", "ডেলিভার্ড"];
      const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
      
      document.getElementById("trackingResult").innerHTML = `
        <h3>ট্র্যাকিং রেজাল্ট: ${parcelId}</h3>
        <p>স্ট্যাটাস: ${randomStatus}</p>
        <p>গন্তব্য: ঢাকা</p>
        <p>ওজন: 2kg</p>
        <p>দাম: ৳40</p>
      `;
      document.getElementById("trackingResult").style.display = "block";
    }, 1000);
  } else {
    alert("পার্সেল আইডি লিখুন!");
  }
}

function showParcelStatus() {
  const timeline = document.getElementById("parcelTimeline");
  timeline.innerHTML = `
    <div class="timeline-step completed">
      <div class="timeline-dot"></div>
      <p>অর্ডার প্রসেসিং</p>
      <small>আজ, সকাল ১০:৩০</small>
    </div>
    <div class="timeline-step completed">
      <div class="timeline-dot"></div>
      <p>পিকআপ সম্পন্ন</p>
      <small>আজ, দুপুর ১২:১৫</small>
    </div>
    <div class="timeline-step active">
      <div class="timeline-dot"></div>
      <p>ট্রানজিটে</p>
      <small>এখন</small>
    </div>
    <div class="timeline-step">
      <div class="timeline-dot"></div>
      <p>ডেলিভারি প্রসেসিং</p>
    </div>
    <div class="timeline-step">
      <div class="timeline-dot"></div>
      <p>ডেলিভার্ড</p>
    </div>
  `;
  timeline.style.display = "block";
}

function updateBookingHistory(trackingNumber) {
  const historyList = document.getElementById("bookingHistory");
  const newItem = document.createElement("li");
  newItem.innerHTML = `
    <span>${new Date().toLocaleDateString()}</span>
    <strong>${trackingNumber}</strong>
    <span>৳${lastPrice}</span>
    <button onclick="trackParcel('${trackingNumber}')">ট্র্যাক করুন</button>
  `;
  historyList.prepend(newItem);
}

function trackParcel(trackingNumber) {
  alert(`ট্র্যাকিং করা হচ্ছে: ${trackingNumber}`);
  navigate('tracking');
  document.getElementById("trackingNumberInput").value = trackingNumber;
  searchParcelById();
}

// Initialize on page load
window.onload = function() {
  generateReceiveDate();
  showParcelStatus();
  
  // Load any saved booking history
  if (localStorage.getItem("bookingHistory")) {
    document.getElementById("bookingHistory").innerHTML = localStorage.getItem("bookingHistory");
  }
};